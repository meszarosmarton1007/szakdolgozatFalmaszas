﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ClimbingApplication.Context;
using ClimbingApplication.Models;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Google.Apis.Auth.OAuth2;
using Google.Cloud.Storage.V1;
using ClimbingApplication.Service;

namespace ClimbingApplication.Controllers
{
    [Route("FalmaszoHelyek/Utak")]
    public class UtakController : Controller
    {
        private readonly EFContextcs _context;
        private readonly IImageService _imageService;
        private readonly IConfiguration _configuration;

        public UtakController(EFContextcs context, IImageService imageService, IConfiguration configuration)
        {
            _context = context;
            _imageService = imageService;
            _configuration = configuration;
        }

        // GET: Utak
        [HttpGet("{falId}")]
        public async Task<IActionResult> Index(int falId)
        {
            IQueryable<Utak> eFContextcs = _context.Utak
                .Include(u => u.Falonut)                //Falnak a neve
                .Include(u => u.UtLetrehozo)            //A mászó aki létrehozta
                .Include(u => u.Hozzaszolasoks)         //hozzászólás betöltése
                    .ThenInclude(h => h.UtHozzaszolo)   //aki a hozzászólást írta
                .Include(u => u.Hozzaszolasoks)         
                    .ThenInclude(h => h.Valaszok)       //válaszok betöltése
                        .ThenInclude(v => v.Valasziro); //a válasznak az írója
        
            eFContextcs = eFContextcs.Where(u => u.FalID == falId);
                
            var fal = await _context.Falak.Include(f => f.Falhelye).AsNoTracking().FirstOrDefaultAsync(f => f.ID == falId);
            if (fal == null)
            {
                 return NotFound();
            }
                
            ViewBag.FalmaszohelyId = fal.Falhelye.ID;//id hozzá lett írva
            ViewBag.FalId = falId;
            ViewBag.FalNev = fal.nev;
            ViewBag.FalmaszohelyNev = fal.Falhelye.nev;

            return View(await eFContextcs.ToListAsync());
            
        }

        // GET: Utak/Details/5
        [HttpGet("Utak/Details/{id}")]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var utak = await _context.Utak
                .Include(u => u.Falonut)
                .Include(U => U.UtLetrehozo)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (utak == null)
            {
                return NotFound();
            }
            ViewBag.FalId = utak.FalID;
            return View(utak);
        }

        // GET: Utak/Create
        [HttpGet("Utak/Create/{falId?}")]
        [Authorize]
        public IActionResult Create(int falId)
        {
            var ut = new Utak
            {
                FalID = falId,
                letrehozva = DateOnly.FromDateTime(DateTime.Now)
            };
            ViewBag.FalId = falId;
            return View(ut);
        }

        // POST: Utak/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("Utak/Create/{falId}")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> Create([Bind("ID,kep,nehezseg,nev,leiras,letrehozva,FalID")] Utak utak, int? falId)
        {
            if (ModelState.IsValid)
            {
                var userIdStr = User.FindFirstValue("userId");

                if (string.IsNullOrEmpty(userIdStr))
                {
                    return Unauthorized();
                }

                utak.FelhasznaloID = int.Parse(userIdStr);
                if (falId.HasValue)
                {
                    utak.FalID = falId.Value;
                }

                _context.Add(utak);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index", new {falId});
            }
            ViewBag.FalId = falId;
            return View(utak);
        }

        // GET: Utak/Edit/5
        [HttpGet("Utak/Edit/{id}")]
        [Authorize]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var utak = await _context.Utak
                .Include(u => u.Falonut)
                .Include(u => u.UtLetrehozo)
                .FirstOrDefaultAsync(u => u.ID == id);
            if (utak == null)
            {
                return NotFound();
            }
           ViewBag.FalId = utak.FalID;
            return View(utak);
        }

        // POST: Utak/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("Utak/Edit/{id}")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> Edit(int id, [Bind("ID,kep,nehezseg,nev,leiras,letrehozva,FalID")] Utak utak)
        {
            if (id != utak.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var existingUt = await _context.Utak
                        .AsNoTracking()
                        .FirstOrDefaultAsync(u => u.ID == id);

                    if (existingUt == null)
                    {
                        return NotFound();
                    }

                    utak.FalID = existingUt.FalID;
                    utak.FelhasznaloID = existingUt.FelhasznaloID;
                    

                    _context.Update(utak);
                    await _context.SaveChangesAsync();

                    return RedirectToAction("Index", new { falId = utak.FalID });
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UtakExists(utak.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                
            }
            ViewBag.FalID = utak.FalID;
            return View(utak);
        }

        // GET: Utak/Delete/5
        [HttpGet("Utak/Delete/{id}")]
        [Authorize]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var utak = await _context.Utak
                .Include(u => u.Falonut)
                .Include(u => u.UtLetrehozo)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (utak == null)
            {
                return NotFound();
            }
            ViewBag.FalId = utak.FalID;
            return View(utak);
        }

       


        // POST: Utak/Delete/5
        //Torlési logika a képekre, hogy először a kép törlődjön
        [HttpPost("Utak/Delete/{id}"), ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var utak = await _context.Utak.FindAsync(id);

            if (utak != null)
            {
                if (!string.IsNullOrEmpty(utak.kep))
                {
                    try
                    {
                        await _imageService.DeleteImageAsync(utak.kep);
                    }
                    catch (Google.GoogleApiException ex)
                    {
                        Console.WriteLine($"A kép nem létezik: {ex.Message}");
                    }
                    catch (Exception ex) 
                    {
                        Console.WriteLine($"Hiba a törlés során: {ex.Message}");
                    }
                }
               


                _context.Utak.Remove(utak);
            }
            
            var falId = utak?.FalID;
            await _context.SaveChangesAsync();
            return RedirectToAction("Index", new { falId });
        }

        private bool UtakExists(int id)
        {
            return _context.Utak.Any(e => e.ID == id);
        }
    }
}
